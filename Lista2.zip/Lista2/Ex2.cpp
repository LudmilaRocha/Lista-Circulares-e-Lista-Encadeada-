/*2. Escreva um programa que implemente uma lista duplamente encadeada que
armazena n�meros inteiros. Fazer uma fun��o para buscar um n�mero na lista.
Autora: Ludmila Rocha Silva
E-mail: ludmila030301@gmail.com
Ano: 2022
*/
//estrutura da lista
#include <stdio.h>
#include <conio.h>
#include <windows.h>
struct LISTA{
int num;
LISTA * prox;
LISTA * ant;
};

//insere no inicio da lista

LISTA * insere_inicio(LISTA * inicio){
LISTA * novo = new LISTA();
printf("Informe um numero:");
scanf("%d", &novo->num);
//se a lista for vazia
if(inicio == NULL){
novo->prox = NULL;
novo->ant = NULL;
inicio = novo;
}else{//insere no inicio da lista
novo->prox = inicio;
novo->ant = NULL;
inicio->ant = novo;
inicio = novo;
}
return inicio;
}

//impressao

void imprime_lista(LISTA * inicio){
if(inicio == NULL){
printf("\nA lista esta vazia");
}else{
LISTA * aux;
printf("\nLista:");
aux = inicio;
while(aux != NULL){
printf("%d", aux->num);
aux = aux->prox;
}
}
}
//busca

void  busca_inicio( LISTA * inicio, int num1){

//se a lista for diferente de vazia
if(inicio != NULL){
LISTA * aux;
aux = inicio;
int achou = 0;
while(aux != NULL){
   if( aux-> num == num1 ){
    printf("Localizado: %d", num1);
    achou = 1;
   }

aux = aux->prox;
}
if(achou == 0){
printf("\nNao foi localizado nenhum elemento!");
}

}

}


//fun��o main

int main(){
LISTA * inicio = NULL;
int menu;
int num1;
do{
system("cls");
printf("\nMenu de Opcoes");
printf("\n1 - Inserir no inicio da lista");
printf("\n2 - Consultar toda a lista");
printf("\n3 - Buscar elemento");
printf("\n4 - Sair");
printf("\nDigite a opcao desejada:");
scanf("%d", &menu);
switch(menu){

case 1:
inicio = insere_inicio(inicio);
break;
case 2:
imprime_lista(inicio);
break;
case 3:
printf("Informe o elemento a ser buscado:");
scanf("%d", &num1);
busca_inicio(inicio, num1);
break;
     }
     getch();
}while(menu != 4);
}


