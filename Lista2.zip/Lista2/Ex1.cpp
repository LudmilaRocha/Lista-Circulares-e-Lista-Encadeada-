/*
1. Escreva um programa que implemente uma lista duplamente encadeada que 
armazena n�meros inteiros. Implemente as opera��es de inserir no in�cio, inserir 
no fim, remo��o e impress�o dos valores da lista. 

Autora: Ludmila Rocha Silva
E-mail: ludmila030301@gmail.com
Ano: 2022

*/
#include <stdio.h>
#include <windows.h>
#include <conio.h>

//registro que representa uma lista
struct LISTA{
	int num;
	LISTA * prox;
	LISTA * ant;
};

//insere no inicio da lista

LISTA * insere_inicio(LISTA * inicio){
	LISTA * novo = new LISTA();
	printf("Informe um numero:");
	scanf("%d", &novo->num);
	//se a lista for vazia 
	if(inicio == NULL){
		novo->prox = NULL;
		novo->ant = NULL;
		inicio = novo;
	} else{//insere no inicio
	novo->prox = inicio;
	novo->ant = NULL;
	inicio->ant = novo;
	inicio = novo;
		
	}
	return inicio;
}

//insere no final da lista 
LISTA * insere_fim(LISTA * inicio){
	LISTA * novo = new LISTA();
	printf("Informe um numero:");
	scanf("%d", &novo->num);
	LISTA * aux = inicio;
	//se a lista for vazia, � o primeiro elemento
	if(inicio == NULL){
		novo->prox = NULL;
		novo-> ant = NULL;
		inicio = novo;
	}else{//insere no final da lista 
		  //enquanto n�o encontrar o �ltimo elemento
		  while(aux->prox != NULL){
		  	aux = aux->prox;
		  }
		  novo->prox = NULL;
		  novo->ant = aux;
		  aux->prox = novo;
		
	}
	return inicio;
}

//impress�o

void imprime_lista(LISTA * inicio)
{
	if(inicio == NULL){
		printf("\nA lista esta vazia");
	}else{
		LISTA * aux;
		printf("\nLista:");
		aux = inicio;
		while(aux != NULL){
			printf(" %d ", aux->num);
			aux = aux->prox;
		}
	}
}

//remove elemento da lista

LISTA * remove_lista(LISTA * inicio){
	int numero, achou = 0;
	printf("Digite o numero que deseja remover:");
	scanf("%d", &numero);
	if(inicio == NULL){
		printf("A lista esta vazia");
	}else{
		LISTA * aux = inicio;
		//enquanto n�o encontrar o numero
		while(aux != NULL){
			if(numero == aux->num){
				//se for o primeiro
				if(aux == inicio){
					inicio = aux->prox;
					if(inicio != NULL){
						inicio->ant = NULL;
					}
					delete(aux);
					aux = inicio;
				}else{
					//se � o ultimo elemento
					if(aux->prox == NULL){
						aux->ant->prox = NULL;
						delete(aux);
						aux = NULL;
					}else{
						aux->ant->prox = aux->prox;
						aux->prox->ant = aux->ant;
						LISTA * aux2;
						aux2 = aux->prox;
						delete(aux);
						aux = aux2;
					}
				}
				achou = achou + 1;
			}else{
				aux = aux->prox;
			}
		} if(achou == 0){
			printf("Numero nao encontrado");
		}else{
			printf("Numero removido %d vezes", achou);
		}
	}
	return inicio;
}

//fun��o main

int main(){
	LISTA * inicio = NULL;
	int menu;
	do{
		system("cls");
		printf("\nMenu de Opcoes");
		printf("\n1 - Inserir no inicio da lista");
		printf("\n2 - Inserir no final da lista");
		printf("\n3 - Consultar toda a lista");
		printf("\n4 - Remover da lista");
		printf("\n5 - Sair");
		printf("\nDigite a opcao desejada:");
		scanf("%d", &menu);
		switch(menu){
			case 1:
				inicio = insere_inicio(inicio);
				break;
			case 2:
				inicio = insere_fim(inicio);
				break;
			case 3:
				imprime_lista(inicio);
				break;
			case 4:
				inicio = remove_lista(inicio);
				break;
				
		}
		getch();
	}while(menu != 5);
}
