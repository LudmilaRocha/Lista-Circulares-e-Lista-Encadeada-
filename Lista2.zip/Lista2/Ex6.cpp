/*
6. Completar o programa a seguir fazendo a inser��o, consulta e remo��o, utilizando 
lista duplamente ligada:
Autora: Ludmila Rocha Silva
E-mail: ludmila030301@gmail.com
Ano:2022
*/
#include <stdio.h>
#include <windows.h>
#include <conio.h>

// estrutura para definir um aluno

struct Aluno {
    int Ra;
    double nota;
};

// registro de cada elemento da lista
struct LISTA {
    Aluno * aluno;
    LISTA * prox;
    LISTA * ant;
};

// inserir no inicio da lista
LISTA * insere_inicio(LISTA * inicio) {

    LISTA * novo = new LISTA();
    novo->aluno = new Aluno();

    printf("Informe o Ra do aluno: \n");
    scanf("%d", &novo->aluno->Ra);

    printf("Informe a nota do aluno: \n");
    scanf("%lf", &novo->aluno->nota);

    // Se a lista for vazia
    if(inicio == NULL) {
        novo -> prox = NULL;
        novo -> ant = NULL;
        inicio = novo;
    } else { // insere no inicio

        novo -> prox = inicio;
        novo -> ant = NULL;
        inicio -> ant = novo;
        inicio = novo;
    }

    return inicio;
}

// inserir no fim da lista
LISTA * insere_fim(LISTA * inicio) {

    LISTA * novo = new LISTA();
    novo->aluno = new Aluno();

    printf("Informe o Ra do aluno: \n");
    scanf("%d", &novo->aluno->Ra);

    printf("informe a nota do aluno: \n");
    scanf("%lf", &novo->aluno->nota);

    LISTA * aux = inicio;

    // Se a lista for vazia
    if(inicio == NULL) {
        novo -> prox = NULL;
        novo -> ant = NULL;
        inicio = novo;
    } else { // insere no fim da LISTA

        while(aux -> prox != NULL) {
            aux = aux -> prox;
        }

        novo -> prox = inicio;
        novo -> ant = NULL;
        inicio -> ant = novo;
        inicio = novo;
    }

    return inicio;
}

LISTA * remove_lista(LISTA * inicio)
{
      int numero, achou=0 ;
      printf("Digite o numero que deseja remover:");
      scanf("%d", & numero);
      
      if (inicio == NULL) {
         printf("A lista esta vazia");
      } else {
         LISTA * aux = inicio;
         // enquanto n�o encontrar o numero
         while (aux != NULL) {
               if (numero == aux->aluno->Ra) {
                  // se for o primeiro
                  if (aux == inicio) {
                     inicio = aux->prox;
                     if (inicio != NULL) {
                        inicio->ant = NULL;
                     }
                     delete(aux);
                     aux = inicio;
                  } else {
                     // se � o ultimo elemento    
                     if (aux->prox == NULL) { 
                         aux->ant->prox = NULL;
                         delete(aux);
                         aux=NULL;
                     } else {              
                         aux->ant->prox = aux->prox;
                         aux->prox->ant = aux->ant;
                         LISTA * aux2;
                         aux2 = aux->prox;
                         delete(aux);
                         aux = aux2;
                     }
                  }
                  achou = achou + 1;
               } else {
                 aux = aux->prox;
               }
         }
         
         if (achou==0)
         {
            printf("Numero n�o encontrado");
         } else {
            printf("Numero removido %d vezes \n", achou);
         }  
      }    
      return inicio;               
}

void imprime_lista(LISTA * inicio) {
    
    if(inicio == NULL) {
        printf("A lista esta vazia \n");
    } else {
        LISTA * aux;
        printf("\n LISTA: ");
        aux = inicio;

        while(aux != NULL) {
            printf(" %d ", aux -> aluno->Ra);
            printf(" %.1lf", aux -> aluno->nota);
            printf("\n");
            aux = aux->prox;
        }
    }
}


int main() {

    LISTA * inicio = NULL;

    int menu;

    do {
        printf("MENU DE OPCOES \n");
        printf("1 - inserir no inicio da lista \n");
        printf("2 - inserir no fim da lista \n");
        printf("3 - Remover um dado da lista \n");
        printf("4 - consultar lista \n");
        printf("5 - sair \n");
        scanf("%d", & menu);

        switch (menu) {
            case 1:
                inicio = insere_inicio(inicio);
                break;

            case 2:
                inicio = insere_fim(inicio);
                break;

            case 3:
                inicio = remove_lista(inicio);
                break;

            
            case 4:
                imprime_lista(inicio);
                break;
        }

    } while(menu != 5);

}
