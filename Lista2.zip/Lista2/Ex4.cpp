/*
4. Escreva um programa que implemente uma lista duplamente encadeada que 
armazena em cada n� uma chave e um nome. As seguintes opera��es abaixo 
devem ser definidas: 
a) Buscar um nome dado o valor da chave; 
b) Inserir um novo elemento na lista; 
c) Remover um elemento da lista;
d) Imprimir os valores da lista;

Autora: Ludmila Rocha Silva
E-mail: ludmila030301@gmail.com
Ano: 2022
*/

//bibliotecas
#include <stdio.h>
#include <conio.h>
#include <windows.h>

//estrutura de uma lista com chave e nome
struct Ex4{
	char nome[50];
	int chave;
};

//estrutura de uma lista 
struct LISTA{
	Ex4 * ex4;
	LISTA * prox;
	LISTA * ant;
};

//insere no inicio da lista
LISTA * insere_inicio(LISTA * inicio){
	LISTA * novo = new LISTA();
	novo->ex4 = new Ex4();
	printf("Informe o nome:");
	scanf("%s", &novo->ex4->nome);
	printf("Informe a chave:");
	scanf("%d", &novo->ex4->chave);
	
	//se a lista for vazia
	if(inicio == NULL){
		novo->prox = NULL;
		novo->ant= NULL;
		inicio = novo;
	}else{// insere no inicio
	novo->prox = inicio;
	novo->ant = NULL;
	inicio->ant= novo;
	inicio = novo;
		
	}
	return inicio;
}
//impress�o
void imprime_lista(LISTA * inicio) {
    
    if(inicio == NULL) {
        printf("A lista esta vazia \n");
    } else {
        LISTA * aux;
        printf("\nLISTA: ");
        aux = inicio;

        while(aux != NULL) {
            printf("Nome: %s ", aux ->ex4->nome);
            printf("Chave: %d", aux ->ex4->chave);
            printf("\n");
            aux = aux->prox;
        }
    }
}


//remove um elemento

LISTA * remove_lista(LISTA * inicio)
{
      int numero, achou=0 ;
      printf("Digite a chave que deseja remover:");
      scanf("%d", & numero);
      
      if (inicio == NULL) {
         printf("A lista esta vazia");
      } else {
         LISTA * aux = inicio;
         // enquanto n�o encontrar o numero
         while (aux != NULL) {
               if (numero == aux->ex4->chave) {
                  // se for o primeiro
                  if (aux == inicio) {
                     inicio = aux->prox;
                     if (inicio != NULL) {
                        inicio->ant = NULL;
                     }
                     delete(aux);
                     aux = inicio;
                  } else {
                     // se � o ultimo elemento    
                     if (aux->prox == NULL) { 
                         aux->ant->prox = NULL;
                         delete(aux);
                         aux=NULL;
                     } else {              
                         aux->ant->prox = aux->prox;
                         aux->prox->ant = aux->ant;
                         LISTA * aux2;
                         aux2 = aux->prox;
                         delete(aux);
                         aux = aux2;
                     }
                  }
                  achou = achou + 1;
               } else {
                 aux = aux->prox;
               }
         }
         
         if (achou==0)
         {
            printf("Numero n�o encontrado\n");
         } else {
            printf("Numero removido %d vezes\n", achou);
         }  
      }    
      return inicio;               
}

//busca de um elemento

void  busca_inicio( LISTA * inicio, int chave1){

//se a lista for diferente de vazia
if(inicio != NULL){
LISTA * aux;
aux = inicio;
int achou = 0;
while(aux != NULL){
   if( aux->ex4->chave == chave1){ 
    printf("Localizado: %s", aux ->ex4->nome);
    achou = 1;
   }

aux = aux->prox;
}
if(achou == 0){
printf("\nNao foi localizado nenhum elemento!");
}

}

}

//fun��o main


int main(){
	LISTA * inicio = NULL;
	int menu, elemento;
	int chave3;
	int chave1;
	do{
		system("cls");
		printf("\nMenu de Opcoes");
		printf("\n1 - Inserir no inicio da lista");
		printf("\n2 - Consultar toda a lista");
		printf("\n3 - Remover");
		printf("\n4 - Busca chave");
		printf("\n5 - Sair");
		printf("\nDigite a opcao deseja:");
		scanf("%d", &menu);
		switch(menu){
			case 1:
				inicio = insere_inicio(inicio);
				break;
			case 2:
				imprime_lista(inicio);
				break;
			case 3:
				inicio = remove_lista(inicio);
				break;
			case 4:
				printf("Informe a chave que deseja buscar:");
				scanf("%d", &chave1);
				busca_inicio(inicio, chave1);
				break;
				
		}
		getch();
	}while(menu != 5);
}
