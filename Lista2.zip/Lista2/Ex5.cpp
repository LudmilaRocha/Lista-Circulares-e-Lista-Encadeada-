/*5. Escreva um programa que implemente uma lista duplamente encadeada que 
armazena n�meros inteiros. Fazer uma fun��o para alterar um n�mero da lista.
Autora: Ludmila Rocha Silva
E-mail: ludmila030301@gmail.com 
Ano:2022
*/
#include <stdio.h>
#include <windows.h>
#include <conio.h>

//registro de representa uma lista
struct LISTA{
	int num;
	LISTA * prox;
	LISTA * ant;
};

//insere no in�cio da lista
LISTA * insere_inicio(LISTA * inicio){
	LISTA * novo = new LISTA();
	printf("Informe um numero:");
	scanf("%d", &novo->num);
	//se a lista for vazia
	if(inicio == NULL){
		novo->prox = NULL;
		novo->ant = NULL;
		inicio = novo;
	}else{//inser��o no inicio
		novo->prox = inicio;
		novo->ant = NULL;
		inicio->ant = novo;
		inicio = novo;
	}
	return inicio;
}

//imprime lista

void imprime_lista(LISTA * inicio)
{
	if(inicio == NULL)
	{
		printf("\nA lista esta vazia");
	}else{
		LISTA * aux;
		printf("\nLista:");
		aux = inicio;
		while(aux != NULL)
		{
			printf("%d", aux->num);
			aux = aux->prox;
		}
	}
 } 
 
//fun��o alterar


LISTA* altera_lista(LISTA *inicio, int old_valor, int new_valor){
	LISTA * aux;
	aux = inicio;

	while (aux!= NULL ){
		if(aux->num != old_valor){
			aux = aux->prox;	
		}else{
			aux->num = new_valor;
		}
		
	}
	
	return aux;
}

//fun��o main

int main(){
	LISTA * inicio = NULL;
	int menu, elemento;
	int valor;
	int valor2;
	do{
		system("cls");
		printf("\nMenu de Opcoes");
		printf("\n1 - Inserir no inicio da lista");
		printf("\n2 - Consultar toda a lista");
		printf("\n3 - Alteracao elemento da lista");
		printf("\n4 - Sair");
		printf("\nDigite a opcao deseja:");
		scanf("%d", &menu);
		switch(menu){
			case 1:
				inicio = insere_inicio(inicio);
				break;
			case 2:
				imprime_lista(inicio);
				break;
			case 3:
				printf("Insira o valor atual: ");
		        scanf("%d", &valor);
		        printf("Insira o valor novo: ");
		        scanf("%d", &valor2);
		        altera_lista(inicio, valor, valor2);
                break;
		}
		getch();
	}while(menu != 5);
}
