/*7. Escreva um programa que implemente uma lista circular que armazena n�meros 
reais. Implemente as opera��es de inserir no in�cio, inserir no fim, remo��o e 
consulta (impress�o) dos valores da lista. 
Nome:Ludmila Rocha Silva
E-mail: ludmila030301@gmail.com
Ano:2022
*/
//bibliotecas
#include <stdio.h>
#include <conio.h>
#include <windows.h>

//estrutura de uma lista
struct LISTA{
	int num;
	LISTA * prox;
};

//inser��o no inicio da lista
LISTA * insere_inicio(LISTA * inicio)
{
	LISTA * novo = new LISTA();
	printf("Informe um numero:");
	scanf("%d", &novo->num);
	//se a lista for vazia, � o primeiro n�
	if(inicio == NULL){
		inicio = novo;
		inicio->prox = inicio;
	}else{
		LISTA * aux = inicio;
		//enquanto n�o chegar no final da lista
		while(aux->prox != inicio){
			aux = aux->prox;
		}
		aux->prox = novo;
		novo->prox = inicio;
		inicio = novo;
	}
	return inicio;
}


//inser��o no fim da lista

LISTA * insere_fim(LISTA * inicio)
{
	LISTA * aux;
	LISTA * novo = new LISTA();
	printf("Informe um numero:");
	scanf("%d", &novo->num);
	//se a lista for vazia
	if(inicio == NULL){
		inicio = novo;
		inicio->prox=inicio;
	}else{
		aux = inicio;
		while(aux->prox != inicio){
			aux = aux->prox;
		}
		aux->prox = novo;
		novo->prox = inicio;
	}
	return inicio;
}

//impress�o
void imprime_lista(LISTA * inicio){
	if(inicio == NULL){
		printf("n\A lista esta vazia");
	}else{
		LISTA * aux;
		printf("\nLista:");
		aux = inicio;
		do
		{
			printf(" %d ", aux->num);
			aux = aux->prox;
		}while(aux!=inicio);
	}
}


//remo��o
LISTA * remove_lista(LISTA * inicio)
{
     int numero, achou=0;
     LISTA * aux;
     LISTA * anterior;
     printf("Informe um numero que deseja remover:");
     scanf("%d", & numero);
     if (inicio == NULL) {
       printf("A lista est� vazia");
     } else {
       aux = inicio;
       anterior = NULL;
       // descobre a quantidade de elementos da lista
       int qtde =0;
       do {
           qtde = qtde+1;
           aux = aux->prox;
       } while (aux != inicio);
       int elemento = 1;
       do {
          if (numero == aux->num) { // se achou, remove
                if (qtde == 1) { // se a lista tem so um elemento
                    delete(inicio);
                    inicio = NULL;
                } else if (aux == inicio) {// se for o primeiro
                   // procura o fim da lista para atualizar
                   LISTA * aux2 = inicio;
                   do {
                       aux2 = aux2->prox; 
                   } while (aux2->prox != inicio); 
                   inicio = aux->prox;
                   aux2->prox = inicio;
                   delete(aux);
                   aux = inicio;         
                } else if (aux->prox == inicio) { // se for o ultimo
                   anterior->prox = inicio;
                   delete(aux);
                   aux = NULL;
                } else { // se est� no meio
                   anterior->prox = aux->prox;
                   delete(aux);
                   aux = anterior->prox;
                }
                achou = achou + 1;
                
          } else {
             anterior = aux;   
             aux = aux->prox;     
          }
          elemento = elemento + 1;
       } while (elemento <= qtde);
       if (achou == 0) {
         printf("\nNumero nao encontrado");
       } else {
         printf("\nNumero removido com sucesso %d vezes", achou);
       }
     }
     return inicio;
}

//fun��o main

int main()
{
	LISTA * inicio = NULL;
	int menu;
	do{
		system("cls");
		printf("\nMENU DE OPCOES");
		printf("\n1 - Inserir no inicio da lista");
		printf("\n2 - Inserir no final da lista");
		printf("\n3- Consultar toda a lista");
		printf("\n4 - Remover da lista");
		printf("\n5 - Sair");
		printf("\nDigite a opcao desejada:");
		scanf("%d", &menu);
		switch(menu){
			case 1:
				inicio = insere_inicio(inicio);
				break;
			case 2:
				inicio = insere_fim(inicio);
				break;
            case 3:
            	imprime_lista(inicio);
				break; 
			case 4:
				inicio = remove_lista(inicio);
				break;		
		}
		getch();
	}while(menu != 5);
}
