/*3. Fa�a um programa que cadastre 5 alunos. Para cada aluno devem ser 
cadastrados nome e nota final. Os dados devem ser armazenados em uma lista 
duplamente encadeada. Em seguida, o programa deve mostrar apenas o nome 
dos alunos aprovados, ou seja, alunos com nota final de no m�nimo 7. Se nenhum 
aluno estiver aprovado, mostrar mensagem

Autora: Ludmila Rocha Silva
E-mail: ludmila030301@gmail.com
Ano: 2022

*/

#include <stdio.h>
#include <conio.h>
#include <windows.h>
// estrutura para definir um aluno

struct Aluno {
    char nome[50];
    double nota;
};

// registro de cada elemento da lista
struct LISTA {
    Aluno * aluno;
    LISTA * prox;
    LISTA * ant;
};

// inserir no inicio da lista
LISTA * insere_inicio(LISTA * inicio) {

    LISTA * novo = new LISTA();
    novo->aluno = new Aluno();

    printf("Informe o nome do aluno: \n");
    scanf("%s", &novo->aluno->nome);

    printf("Informe a nota do aluno: \n");
    scanf("%lf", &novo->aluno->nota);

    // Se a lista for vazia
    if(inicio == NULL) {
        novo -> prox = NULL;
        novo -> ant = NULL;
        inicio = novo;
    } else { // insere no inicio

        novo -> prox = inicio;
        novo -> ant = NULL;
        inicio -> ant = novo;
        inicio = novo;
    }

    return inicio;
}


void imprime_lista(LISTA * inicio) {
    
    if(inicio == NULL) {
        printf("A lista esta vazia \n");
    } else {
        LISTA * aux;
        printf("\nLISTA: ");
        aux = inicio;

        while(aux != NULL) {
        	//verificao da nota
            if(aux -> aluno->nota >= 7){
        	printf("\nNome: %s ", aux -> aluno->nome);
            printf("\nNota: %.1lf", aux -> aluno->nota);
            printf("\nSituacao: Aprovado\n");	
			}else{
				printf("\nNenhum aluno foi aprovado!\n");
				
			}
			
            aux = aux->prox;
        }
    }
}


//fun��o main

int main() {

    LISTA * inicio = NULL;

    int menu;

    do {
        printf("\nMENU DE OPCOES \n");
        printf("1 - Inserir no inicio da lista \n");
        printf("2 - Consultar lista \n");
        printf("3 - Sair \n");
        scanf("%d", & menu);

        switch (menu) {
            case 1:
                inicio = insere_inicio(inicio);
                break;
            
            case 2:
                imprime_lista(inicio);
                break;
        }

    } while(menu != 3);

}
